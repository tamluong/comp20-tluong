/**
 * Module dependencies.
 */
var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongodb');

var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.logger());
app.use(express.bodyParser());
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', function (req, res) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
  	mongo.Db.connect(mongoUri, function (err, db){
  	if (!err) {
  		db.collection("trial", function (er, col){
      		var d = col.find({}).sort({score:-1}).toArray(function(err, x){
        		res.set('Content-Type', 'text/html');
  				var table = '<table id="table"><tr>' +
                    '<th>Username</th><th>Score</th>' +
                    '<th>Timestamp</th></tr>';
        		for (var i=0; i<x.length; i++) {
        			table += '<tr><td>' + x[i].username + '</td>'
        				+ '<td>' + x[i].score + '</td>'
        				+ '<td>' + x[i].timestamp + '</td></tr>';
        		}
        		res.send(table);
      		});
    	});
    }
  	});
});

app.get('/scores.json', function(req, res) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
  	var username = req.query.username; // dealing with a query variable
  	// Example: on your web browser, go to http://[domain here, e.g., localhost]:3000/data.json?username=batman
  	console.log("I see a username: " + username)
  	mongo.Db.connect(mongoUri, function (err, db){
    	db.collection("trial", function (er, col){
      		var d = col.find({"username":username}).sort({score:-1}).toArray(function(err, x){
        		//res.set('Content-Type', 'text/json');
  				res.send(x);
      		});
    	});
  	});
});

app.get('/users', user.list);

app.post('/submit.json', function (req, res){
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
  	mongo.Db.connect(mongoUri, function (err, db){
    	db.collection("trial", function (er, collection){
      		var score = Number(req.body.score);
      		var username = req.body.username;
      		var grid = req.body.grid;
      		var date = new Date();
      		collection.insert({"username":username, "score":score,
      						"grid": grid, "timestamp":date}, function (err, r){});
      		res.send("hey i got your POST!");
    	});
  	});
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});